package com.example.ridesharing;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.google.firebase.storage.FirebaseStorage.getInstance;

public class DashboardActivity extends AppCompatActivity {



    //firebase auth
    FirebaseAuth firebaseAuth;
    FirebaseUser user;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    StorageReference storageReference;
    CircleImageView  navImage;
    ActionBar actionBar;
    DrawerLayout dl;
    ActionBarDrawerToggle t;
    TextView Nemail,Nname;
    String mUID;
    Toolbar maintoolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);




        //Actionbar and its title
        actionBar = getSupportActionBar();

        //init
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Users");
        storageReference = getInstance().getReference();//firebase storage reference
        String storagePath = "Users_Profile_Cover_Imgs/";
        //bottom navigation
        NavigationView navigationView= findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(selectedListener);
        navImage = navigationView.getHeaderView(0).findViewById(R.id.nav_header_avatar);
        Nemail = (TextView) navigationView.getHeaderView(0).findViewById(R.id.nav_email);
        Nname = (TextView) navigationView.getHeaderView(0).findViewById(R.id.nav_name);
        dl = findViewById(R.id.home_d);
        t = new ActionBarDrawerToggle(this, dl,R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        dl.addDrawerListener(t);

        t.syncState();
        actionBar.setDisplayHomeAsUpEnabled(true);

        Uri image_uri;
        String profileorCoverPhoto;
        String uid;
        actionBar.setTitle("Home");//change actionbar title

        HomeFragment fragment1= new HomeFragment();
        FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
        ft1.replace(R.id.content,fragment1,"");
        ft1.commit();
        checkUserStatus();
        //update token
       // updateToken(FirebaseInstanceId.getInstance().getToken());


        Query query = databaseReference.orderByChild("email").equalTo(user.getEmail());
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                //checkc until required data get
                for(DataSnapshot ds: dataSnapshot.getChildren()){

                    //get data
                    String name = "" + ds.child("name").getValue();
                    String email = "" + ds.child("email").getValue();
                    String image = "" + ds.child("image").getValue();


                    //set data
                    Nname.setText(name);
                    Nemail.setText(email);


                    try{
                        //if image is received then set
                        Picasso.get().load(image).into(navImage);
                    }
                    catch (Exception e){

                        // if there is any exception while getting image then set default

                        Picasso.get().load(R.drawable.default_profile).into(navImage);
                    }

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        t.syncState();
    }

    @Override
    protected void onResume() {
        checkUserStatus();
        super.onResume();
    }

   /*public void updateToken(String token){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Tokens");
        Token mToken = new Token(token);
        ref.child(mUID).setValue(mToken);

    }*/

    private NavigationView.OnNavigationItemSelectedListener selectedListener = new NavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            //handle item clicks

            switch (menuItem.getItemId()){

                case R.id.nav_home:
                    //home fragment transaction
                    actionBar.setTitle("Home");//change actionbar title
                    HomeFragment fragment1= new HomeFragment();
                    FragmentTransaction ft1 = getSupportFragmentManager().beginTransaction();
                    ft1.replace(R.id.content,fragment1,"");
                    ft1.commit();
                    return true;
                case R.id.nav_profile:
                    //Profile fragment transaction
                    actionBar.setTitle("Profile");//change actionbar title
                    ProfileFragment fragment2= new ProfileFragment();
                    FragmentTransaction ft2 = getSupportFragmentManager().beginTransaction();
                    ft2.replace(R.id.content,fragment2,"");
                    ft2.commit();
                    return true;
                case R.id.nav_users:
                    //Users fragment transaction
                    actionBar.setTitle("Users");//change actionbar title
                    UsersFragment fragment3= new UsersFragment();
                    FragmentTransaction ft3 = getSupportFragmentManager().beginTransaction();
                    ft3.replace(R.id.content,fragment3,"");
                    ft3.commit();
                    return true;
                case R.id.nav_logout:
                    //Users fragment transaction
                    //FirebaseAuth.getInstance().signOut();
                    finish();
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    //finish();
                    return true;
            }

            return false;
        }
    };
    private void checkUserStatus(){
        //get current user
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if(user!=null){
            //user is signed in stay here
            //set email of logged in user
            mUID = user.getUid();

            //save uid of currently signed in user in shared preferences.
            SharedPreferences sp = getSharedPreferences("SP_USER",MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("Current_USERID",mUID);
            editor.apply();
            //updateToken(FirebaseInstanceId.getInstance().getToken());

        }
        else{
            startActivity(new Intent(DashboardActivity.this,MainActivity.class));
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        if (dl.isDrawerOpen(GravityCompat.START)) {
            dl.closeDrawer(GravityCompat.START);

        } else {
            super.onBackPressed();
            finish();
        }
    }

    @Override
    protected void onStart(){
        //check on start of app

        checkUserStatus();
        super.onStart();


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        if(t.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);

    }



}
