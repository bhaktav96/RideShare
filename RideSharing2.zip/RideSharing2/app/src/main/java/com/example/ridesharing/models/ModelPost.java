package com.example.ridesharing.models;

public class ModelPost {

    //use same name as we given while uploading post
    String pId,pSource,pDescr,pDestination,pCurrencyEt,pImage,pTime,uid,uEmail,uDp,uName,pctime,pdate;

    public ModelPost() {
    }

    public ModelPost(String pId, String pSource, String pDescr, String pDestination, String pCurrencyEt, String pImage, String pTime, String uid, String uEmail, String uDp, String uName, String pctime,String pdate) {
        this.pId = pId;
        this.pSource = pSource;
        this.pDescr = pDescr;
        this.pDestination = pDestination;
        //this.pDate = pDate;
        this.pCurrencyEt = pCurrencyEt;
        this.pImage = pImage;
        this.pTime = pTime;
        this.uid = uid;
        this.uEmail = uEmail;
        this.uDp = uDp;
        this.uName = uName;
        this.pctime = pctime;
        this.pdate = pdate;
    }

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }

    public String getpSource() {
        return pSource;
    }

    public void setpSource(String pSource) {
        this.pSource = pSource;
    }

    public String getpDescr() {
        return pDescr;
    }

    public void setpDescr(String pDescr) {
        this.pDescr = pDescr;
    }

    public String getpDestination() {
        return pDestination;
    }

    public void setpDestination(String pDestination) {
        this.pDestination = pDestination;
    }



    public String getpCurrencyEt() {
        return pCurrencyEt;
    }

    public void setpCurrencyEt(String pCurrencyEt) {
        this.pCurrencyEt = pCurrencyEt;
    }

    public String getpImage() {
        return pImage;
    }

    public void setpImage(String pImage) {
        this.pImage = pImage;
    }

    public String getpTime() {
        return pTime;
    }

    public void setpTime(String pTime) {
        this.pTime = pTime;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getuEmail() {
        return uEmail;
    }

    public void setuEmail(String uEmail) {
        this.uEmail = uEmail;
    }

    public String getuDp() {
        return uDp;
    }

    public void setuDp(String uDp) {
        this.uDp = uDp;
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getpctime() {
        return pctime;
    }

    public void setpctime(String pctime) {
        this.pctime = pctime;
    }

    public String getpdate() {
        return pdate;
    }

    public void setpdate(String pdate) {
        this.pdate = pdate;
    }
}
