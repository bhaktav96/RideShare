package com.example.ridesharing.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ridesharing.AddPostActivity;
import com.example.ridesharing.ChatActivity;
import com.example.ridesharing.R;
import com.example.ridesharing.ThereProfileActivity;
import com.example.ridesharing.models.ModelPost;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class AdapterPosts extends RecyclerView.Adapter<AdapterPosts.MyHolder>{

    Context context;
    private List<ModelPost> postList;
    //private List<ModelUser> userList;


    String myUid,hisUid;

    private DatabaseReference likesRef;//for likes database node
    private DatabaseReference postsRef;//reference of posts

    boolean mProcessLike = false;

    public AdapterPosts(Context context, List<ModelPost> postList) {
        this.context = context;
        this.postList = postList;
        //this.userList =userList;
        myUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        likesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
        postsRef = FirebaseDatabase.getInstance().getReference().child("Posts");

    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        //inflate layout row_post.xml
        View view = (View) LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_posts,viewGroup,false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder myHolder, final int i) {

        ModelPost p = postList.get(i);
        //ModelUser a = userList.get(i);
        //final String hisUid = a.getUid();
        //final String hisUID = userList.get(i).getUid();
        final String pId= p.getpId();
        final String uid = p.getUid();
        Calendar calender = Calendar.getInstance(Locale.getDefault());
        calender.setTimeInMillis(Long.parseLong(p.getpTime()));
        String pTime = DateFormat.format("dd/MM/yyyy hh:mm aa",calender).toString();
        // String pLikes = postList.get(i).getpLikes(); // Contains total number of likes
        //String pComments = postList.get(i).getpComments();

        String pImage = postList.get(i).getpImage();
        String uDp = postList.get(i).getuDp();
        myHolder.uNameTv.setText(p.getuName());
        myHolder.uEmailTv.setText(p.getuEmail());
        myHolder.pTimeTv.setText(pTime);
        myHolder.pSourceTv.setText("Source: "+p.getpSource());
        myHolder.pDestinationTv.setText("Destination:"+p.getpDestination());
        //myHolder.pDateTv.setText("Date:"+p.getpDate());
        myHolder.pDescriptionTv.setText("Enter Details:"+p.getpDescr());
        myHolder.pCurrencyTv.setText("Rate:"+p.getpCurrencyEt());
        myHolder.timeTv.setText("Time:"+p.getpctime());
        myHolder.dateTv.setText("Date:"+p.getpdate());

        try{
            Picasso.get().load(uDp).placeholder(R.drawable.ic_default_img).into(myHolder.uPictureIv);
        }
        catch (Exception e)
        {

        }

        //myHolder.pLikesTv.setText(pLikes + " Interested");
        //myHolder.pCommentsTv.setText(pComments + "Messages");

        //setLikes(myHolder,pId);

       /*

        //get data
        String uid = postList.get(i).getUid();
        String uEmail = postList.get(i).getuEmail();
        String uName = postList.get(i).getuName();
        String uDp = postList.get(i).getuDp();
        String pId = postList.get(i).getpId();
        String pTitle = postList.get(i).getpTitle();
        String pDescription = postList.get(i).getpDescr();
        String pImage = postList.get(i).getpImage();
        String pTimeStamp = postList.get(i).getpTime();
        String pCurrencyEt = postList.get(i).getpCurrencyEt();

        //convert timestamp to dd/mm/yyyy hh:mm am/pm
        Calendar calender = Calendar.getInstance(Locale.getDefault());
        calender.setTimeInMillis(Long.parseLong(pTimeStamp));
        String pTime = DateFormat.format("dd/MM/yyyy hh:mm aa",calender).toString();

        //set data
        myHolder.uNameTv.setText(uName);
        myHolder.pTimeTv.setText(pTime);
        myHolder.pTitleTv.setText(pTitle);
        myHolder.pDescriptionTv.setText(pDescription);
        myHolder.pCurrencyTv.setText(pCurrencyEt);
        //set user dp
        try{
            Picasso.get().load(uDp).placeholder(R.drawable.ic_default_img).into(myHolder.uPictureIv);
        }
        catch (Exception e)
        {

        }

        if(pImage.equals("noImage")){
            //hide imageview
            myHolder.pImageIv.setVisibility(View.GONE);
        }
        else
        {
            try
            {
                Picasso.get().load(pImage).into(myHolder.pImageIv);
            }
            catch (Exception e){

            }
        }

*/


        //if there is no image then hide ImageView

        //handle button clicks
        myHolder.moreBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //later
                showMoreOptions(myHolder.moreBtn,uid,myUid,pId,pImage);
            }
        });

        myHolder.commentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //later
                if(uid.equals(hisUid)){

                    Intent intent = new Intent(context, ChatActivity.class);
                    intent.putExtra("hisUid",uid);
                    context.startActivity(intent);

                }else{


                }

            }
        });

      /*  myHolder.likeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //later

                int pLikes = Integer.parseInt(postList.get(i).getpLikes());
                mProcessLike = true;
                //get id of post clicked
                final String postIde = postList.get(i).getpId();
                likesRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if(mProcessLike){

                            if(dataSnapshot.child(postIde).hasChild(myUid)){

                                //already liked, so remove like

                                postsRef.child(postIde).child("pLikes").setValue(""+(pLikes-1));
                                likesRef.child(postIde).child(myUid).removeValue();
                                mProcessLike = false;


                            }
                            else{

                                postsRef.child(postIde).child("pLikes").setValue(""+(pLikes+1));
                                likesRef.child(postIde).child(myUid).setValue("Interested");
                                mProcessLike = false;
                            }


                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });*/

        /*myHolder.profileLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //later

                Intent intent = new Intent(context, ThereProfileActivity.class);
                intent.putExtra("uid",uid);
                context.startActivity(intent);
            }
        });*/
    }

    /*private void setLikes(final MyHolder holder, final String postKey) {

        likesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.child(postKey).hasChild(myUid)){

                    //user has liked this post
                    //To indicate that post is liked by signed user
                    //change drwable left icon of like button
                    //change text of like button from like to Liked

                    holder.likeBtn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_liked,0,0,0);
                    holder.likeBtn.setText("Interested");

                }
                else{

                    //user has not like this post
                    holder.likeBtn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_like_black,0,0,0);
                    holder.likeBtn.setText("Interest");


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
*/
    @Override
    public int getItemCount() {
        return postList.size();
    }

    private void showMoreOptions(ImageButton moreBtn,String uid,String myUid , final String pId,final  String pImage){

        //creating  pop menu currently having option delete
        PopupMenu popupMenu = new PopupMenu(context,moreBtn, Gravity.END);

        if(uid.equals(myUid)){
            //add items in menu
            popupMenu.getMenu().add(Menu.NONE,0,0,"Delete");
            popupMenu.getMenu().add(Menu.NONE,1,0,"Edit");

        }
        else{
            popupMenu.getMenu().add(Menu.NONE,2,0,"Chat");
        }

        // popupMenu.getMenu().add(Menu.NONE,2,0,"View Detail");


        //item click listener
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                int id = item.getItemId();

                if (id == 0) {
                    //delete is clicked
                    beginDelete(pId, pImage);
                } else if (id == 1) {
                    //edit is clicked
                    Intent intent = new Intent(context, AddPostActivity.class);
                    intent.putExtra("key", "editPost");
                    intent.putExtra("editPostId", pId);
                    context.startActivity(intent);
                } else if (id == 2) {

                    /*Intent intent = new Intent(context, PostDetailActivity.class);

                    intent.putExtra("postId", pId);
                    context.startActivity(intent);*/
                    Intent intent = new Intent(context, ChatActivity.class);
                    intent.putExtra("hisUid",uid);
                    context.startActivity(intent);

                    Toast.makeText(context,"Go to ChatBox",Toast.LENGTH_SHORT).show();
                }

                return false;
            }

        });

        popupMenu.show();
    }

    private void beginDelete(String pId, String pImage) {
        if(pImage.equals("noImage")){
            deleteWithoutImage(pId);
        }
        else{
            deleteWithImage(pId,pImage);
        }
    }

    private void deleteWithImage(String pId, String pImage) {
        //progress bar
        //progress bar
        final ProgressDialog pd = new ProgressDialog(context);
        pd.setMessage("Deleting .....");

        StorageReference picRef = FirebaseStorage.getInstance().getReferenceFromUrl(pImage);
        picRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                //image deleted, now delete database
                Query fquery = FirebaseDatabase.getInstance().getReference("Posts").orderByChild("pId").equalTo(pId);
                fquery.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot ds: dataSnapshot.getChildren()){

                            ds.getRef().removeValue();//remove values from firebase where pid mathches

                        }
                        //deleted
                        Toast.makeText(context,"Deleted successfully",Toast.LENGTH_SHORT).show();
                        pd.dismiss();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(context,""+e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void deleteWithoutImage(String pId) {

        final ProgressDialog pd = new ProgressDialog(context);
        pd.setMessage("Deleting .....");

        Query fquery = FirebaseDatabase.getInstance().getReference("Posts").orderByChild("pId").equalTo(pId);
        fquery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()){

                    ds.getRef().removeValue();//remove values from firebase where pid mathches

                }
                //deleted
                Toast.makeText(context,"Deleted successfully",Toast.LENGTH_SHORT).show();
                pd.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    //view holder class
    class MyHolder extends RecyclerView.ViewHolder{

        //Views from row_post.xml
        private ImageView uPictureIv;
        private TextView uNameTv,pTimeTv,pSourceTv,pDestinationTv,pDateTv,pDescriptionTv,pCurrencyTv, pLikesTv, uEmailTv,timeTv,dateTv;
        private ImageButton moreBtn;
        private Button commentBtn,likeBtn;
        LinearLayout profileLayout;


        public MyHolder(@NonNull View itemView){
            super(itemView);



            //init views
            uPictureIv = itemView.findViewById(R.id.uPictureIv);
            //pImageIv = itemView.findViewById(R.id.pImageIv);
            uNameTv = itemView.findViewById(R.id.uNameTv);
            uEmailTv = itemView.findViewById(R.id.emailnew);
            pTimeTv = itemView.findViewById(R.id.pTimeTv);
            pSourceTv = itemView.findViewById(R.id.pSourceTv);
            pDestinationTv = itemView.findViewById(R.id.pDestinationTv);
            //pDateTv=itemView.findViewById(R.id.pDateTv);
            pCurrencyTv = itemView.findViewById(R.id.pCurrencyTv);
            pDescriptionTv = itemView.findViewById(R.id.pdescriptionTv);
            timeTv = itemView.findViewById(R.id.timeTv);
            dateTv = itemView.findViewById(R.id.dateTv);
            moreBtn = itemView.findViewById(R.id.moreBtn);
            commentBtn = itemView.findViewById(R.id.commentBtn);
            profileLayout = itemView.findViewById(R.id.profileLayout);


        }
    }
}
